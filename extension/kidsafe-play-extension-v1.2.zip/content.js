// Runs only on the parent's (login-gated) Blocked-sites page. That page embeds the
// parent's private API link + token for the signed-in owner; this script hands them
// to the extension so the child's device gets connected automatically — the parent
// never copies a token by hand. Nothing here is shown to, or usable by, the child.

(function () {
  var el = document.getElementById('kidsafe-connect');
  if (!el) { return; }

  var apiUrl = (el.getAttribute('data-api') || '').trim();
  var apiToken = (el.getAttribute('data-token') || '').trim();
  var name = (el.getAttribute('data-name') || '').trim();
  if (!apiUrl || !apiToken) { return; }

  // Background stores these, greets the parent, and refreshes the block list.
  chrome.runtime.sendMessage({
    type: 'connect',
    apiUrl: apiUrl,
    apiToken: apiToken,
    name: name
  });
})();
