// KidSafe Play popup. Deliberately child-safe: it never mentions blocking or shows
// any list — a child using this device learns nothing about it. There are only two
// states:
//   • not set up  -> a "Setup" button that opens the parent sign-in page. After the
//                    parent logs in, the page's content script sends the token here
//                    automatically (see content.js / background.js).
//   • set up      -> "Welcome, <name>!" so the parent knows the device is connected.
// The block list itself is managed only on the parent's /parent/blocklist page.

var DEFAULT_BASE = 'https://genai.io.vn';   // production KidSafe Play
var SETUP_PATH = '/parent/blocklist';       // login-gated; content script connects on arrival

function $(id) { return document.getElementById(id); }

/** Open the parent sign-in / setup page in a new tab, then close the popup. */
function openSetup() {
  chrome.tabs.create({ url: DEFAULT_BASE + SETUP_PATH });
  window.close();
}

function render(cfg) {
  $('loading').hidden = true;
  var connected = !!(cfg.apiUrl && cfg.apiToken);
  $('setup').hidden = connected;
  $('done').hidden = !connected;
  if (connected) {
    $('who').textContent = (cfg.parentName && cfg.parentName.trim()) ? cfg.parentName.trim() : 'there';
    var v = cfg.dataVersion;
    $('ver').textContent = (typeof v === 'number') ? v : '—';   // em dash if unknown yet
  }
}

async function load() {
  var cfg = await chrome.storage.local.get(['apiUrl', 'apiToken', 'parentName', 'dataVersion']);
  render(cfg);
}

$('setupBtn').addEventListener('click', openSetup);
$('switchBtn').addEventListener('click', openSetup);

// Refresh now: pull the list from the server immediately instead of waiting for the
// ~10-min alarm, then re-render so the shown Data version reflects what was just fetched.
$('refreshBtn').addEventListener('click', function () {
  var btn = $('refreshBtn');
  btn.disabled = true;
  btn.textContent = 'Refreshing…';
  $('flash').textContent = '';
  chrome.runtime.sendMessage({ type: 'refresh' }, function () {
    chrome.storage.local.get(['apiUrl', 'apiToken', 'parentName', 'dataVersion', 'lastError'], function (cfg) {
      render(cfg);
      $('flash').textContent = cfg.lastError ? ('Sync problem — will retry') : ('Up to date ✓');
      btn.disabled = false;
      btn.textContent = 'Refresh now';
    });
  });
});

// Live-update if the popup is still open when the content script connects the device
// or a background refresh lands a new version.
chrome.storage.onChanged.addListener(function (changes, area) {
  if (area !== 'local') { return; }
  if (changes.apiUrl || changes.apiToken || changes.parentName || changes.dataVersion) { load(); }
});

load();
