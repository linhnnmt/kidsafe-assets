// KidSafe Play — blocks the sites a parent chooses. It reads the parent's list
// from the KidSafe Play app's private API (/api/blocklist) using the endpoint URL
// + token they paste into the popup (Authorization: Bearer <token>). The list is
// refreshed on browser start, on install, whenever the parent saves new settings,
// and automatically about every 10 minutes — so changes on the dashboard take up
// to ~10 minutes to reach the child's device.

const REFRESH_MINUTES = 10;

function wait(ms) { return new Promise((r) => setTimeout(r, ms)); }

/** The endpoint URL + token the parent pasted in the popup (from /blocklist). */
async function getConfig() {
  const c = await chrome.storage.local.get(['apiUrl', 'apiToken']);
  return { apiUrl: (c.apiUrl || '').trim(), apiToken: (c.apiToken || '').trim() };
}

// Fetch the parent's blocked-sites list. Transient failures (network not up on
// browser start, wifi blip, worker wake) are warnings, not errors — the next
// alarm retries and we keep the last-known rules in the meantime.
async function fetchBlockList(retries = 2) {
  const { apiUrl, apiToken } = await getConfig();
  if (!apiUrl || !apiToken) {
    console.warn('KidSafe Play: not set up yet — open the extension and paste your API link + token.');
    return null;
  }
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      const response = await fetch(apiUrl, {
        cache: 'no-store',
        headers: { 'Authorization': 'Bearer ' + apiToken }
      });
      if (!response.ok) { throw new Error('HTTP ' + response.status); }
      const data = await response.json();
      return {
        sites: Array.isArray(data.blockedSites) ? data.blockedSites : [],
        version: (typeof data.version === 'number') ? data.version : null
      };
    } catch (error) {
      if (attempt < retries) {
        console.warn(`KidSafe Play: fetch attempt ${attempt + 1} failed, retrying…`, error.message);
        await wait(1500 * (attempt + 1));
      } else {
        await chrome.storage.local.set({ lastError: error.message, lastRun: Date.now() });
        console.warn('KidSafe Play: fetch failed; keeping last-known list, will retry:', error.message);
      }
    }
  }
  return null;
}

// Coalesce concurrent runs (connect + storage.onChanged + alarm can overlap): a call
// while one is in flight returns the same promise, so we never fire two rule updates at
// once (which would collide on rule IDs and throw).
let inFlight = null;
function updateBlocklist() {
  if (inFlight) { return inFlight; }
  inFlight = doUpdate().finally(() => { inFlight = null; });
  return inFlight;
}

async function doUpdate() {
  const result = await fetchBlockList();
  if (!result) { return; }   // no config / failure -> keep existing rules
  const sites = result.sites;

  // Record what we fetched FIRST — the popup's "Data version" must reflect the latest
  // successful fetch even if the rules update below hiccups.
  await chrome.storage.local.set({
    lastCount: sites.length,
    dataVersion: result.version,
    lastError: '',
    lastRun: Date.now()
  });

  const rules = sites.map((site, index) => ({
    id: index + 1,
    priority: 1,
    action: { type: 'block' },
    condition: { urlFilter: String(site), resourceTypes: ['main_frame'] }
  }));

  try {
    const oldRules = await chrome.declarativeNetRequest.getDynamicRules();
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: oldRules.map((r) => r.id),
      addRules: rules
    });
  } catch (e) {
    await chrome.storage.local.set({ lastError: 'rules: ' + (e && e.message ? e.message : e) });
    console.warn('KidSafe Play: rules update failed —', e);
    return;
  }
  console.log('KidSafe Play: blocklist updated —', sites.length, 'sites, version', result.version, 'at', new Date().toLocaleTimeString());
}

// Refresh on browser start and on install/update.
chrome.runtime.onStartup.addListener(updateBlocklist);
chrome.runtime.onInstalled.addListener(() => updateBlocklist());

// Automatic refresh loop (~every 10 minutes).
chrome.alarms.create('fetchConfigAlarm', { delayInMinutes: 0.5, periodInMinutes: REFRESH_MINUTES });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'fetchConfigAlarm') { return updateBlocklist(); }
});

// Re-pull immediately when the parent saves a new endpoint/token in the popup.
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && (changes.apiUrl || changes.apiToken)) { return updateBlocklist(); }
});

// Messages from the popup and the connect content script.
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) { return; }

  // The parent opened their Blocked-sites page: the content script sends the API
  // link + token + their name. Store them (storage.onChanged then refreshes) and
  // remember the name so the popup can greet them with "Welcome, <name>".
  if (msg.type === 'connect' && msg.apiUrl && msg.apiToken) {
    chrome.storage.local.set({
      apiUrl: String(msg.apiUrl).trim(),
      apiToken: String(msg.apiToken).trim(),
      parentName: (msg.name || '').trim(),
      lastError: ''
    }).then(() => updateBlocklist())
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;   // async response
  }

  // Popup "refresh now".
  if (msg.type === 'refresh') {
    updateBlocklist().then(() => sendResponse({ ok: true })).catch(() => sendResponse({ ok: false }));
    return true;   // async response
  }
});
